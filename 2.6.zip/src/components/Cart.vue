<template>
  <div>
    <h2 class="title is-2">{{ showTotal }}</h2>
    <div class="columns">
      <div v-for="item in cartProducts" :key="item.id" class="column is-4">
        <div class="box">
          <article class="media">
            <div class="media-left">
              <figure class="image is-128x128">
                <img :src="item.imgSrc" :alt="item.name">
              </figure>
            </div>
            <div class="media-content">
              <div class="content">
                <p>
                  <strong>{{ item.name }}</strong> <small>{{ item.price }} €</small><br/>
                  x {{ item.quantity }} ({{ item.price * item.quantity }} €)
                  <br>
                  {{ item.description }}
                </p>
              </div>
              <nav class="level is-mobile">
                <div class="level-left">
                  <a class="level-item" aria-label="cart-plus">
                    <span class="icon has-text-info is-medium" @click="$emit('addToCart', { product: item })">
                      <i class="fas fa-2x fa-cart-plus" aria-hidden="true"></i>
                    </span>
                  </a>
                </div>
                <div class="level-right">
                  <a class="level-item" aria-label="cart-arrow-down">
                    <span class="icon has-text-danger is-medium" @click="$emit('removeFromCart', { product: item })">
                      <i class="fas fa-2x fa-cart-arrow-down" aria-hidden="true"></i>
                    </span>
                  </a>
                </div>
              </nav>
            </div>
          </article>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Cart',
  props: {
    items: Array
  },
  computed: {
    cartProducts() {
      const toRet = [];

      this.items.forEach(item => {
        // Verifichiamo se item è stato già aggiunto a toRet
        const alreadyPushed = toRet.find(product => product.id === item.id);
        if (alreadyPushed) {
          // Se è già presente, ne incrementiamo la quantità di 1
          alreadyPushed.quantity += 1;
        } else {
          toRet.push({ ...item, quantity: 1 });
        }
      });

      return toRet;
    },
    showTotal() {
      const total = this.items.reduce((acc, item) => acc + item.price, 0);
      return `Totale carrello: ${total} €`;
    }
  }
}
</script>
