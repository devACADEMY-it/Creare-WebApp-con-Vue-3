import CryptoList from "../components/CryptoList";
import CryptoInfo from "../components/CryptoInfo";
import { createWebHashHistory, createRouter } from "vue-router";

const routes = [
  {
    path: "/",
    component: CryptoList,
  },
  {
    path: "/crypto/:id",
    component: CryptoInfo,
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
