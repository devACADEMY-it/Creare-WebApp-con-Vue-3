<template>
  <h1>Cripto Info</h1>
</template>

<script>
export default {

}
</script>
