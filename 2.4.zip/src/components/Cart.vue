<template>
  <div>
    <h2 class="title is-2">{{ showTotal }}</h2>
    <div class="columns">
      <div v-for="item in items" :key="item.id" class="column is-3">
        <div class="card">
          <div class="card-content">
            <p class="title">
              {{ item.name }}
            </p>
            <p class="subtitle">
              {{ item.price }}
            </p>
          </div>
          <footer class="card-footer">
            <p class="card-footer-item">
              <button class="button is-info">
                +
              </button>
            </p>
            <p class="card-footer-item">
              <button class="button is-danger">
                -
              </button>
            </p>
          </footer>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Cart',
  props: {
    items: Array
  },
  computed: {
    showTotal() {
      const total = this.items.reduce((acc, item) => acc + item.price, 0);
      return `Totale carrello: ${total}`;
    }
  }
}
</script>
