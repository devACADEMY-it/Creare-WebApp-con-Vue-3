<template>
  <div class="container is-fluid">
    <Navbar brand="Vue Store" />

    <section class="section">
      <ProductList :products="products" @addToCart="onAddToCart($event)" />

      <Cart :items="cart.items" />
    </section>
  </div>
</template>

<script>
import ProductList from './components/ProductList';
import Navbar from "./components/Navbar";
import Cart from "./components/Cart";

export default {
  name: 'App',
  components: {
    Cart,
    Navbar,
    ProductList
  },
  data() {
    return {
      products: [
        {
          id: 1,
          imgSrc: require('./assets/glasses.png'),
          name: 'Carmhack Glasses',
          inStock: true,
          price: 40,
          inventory: 15,
          description: 'Best glasses in the world',
        },
        {
          id: 2,
          imgSrc: require('./assets/bag.png'),
          name: 'Bag',
          inStock: true,
          price: 25,
          inventory: 4,
          description: 'Best bag in the world',
        },
        {
          id: 3,
          imgSrc: require('./assets/shoe.png'),
          name: 'Gigi Shoe',
          inStock: true,
          price: 34,
          inventory: 0,
          description: 'Best shoes in the world',
        },
        {
          id: 4,
          imgSrc: require('./assets/watch.png'),
          name: 'Watch da polso',
          inStock: true,
          price: 120,
          inventory: 20,
          description: 'Best watch in the world',
        }
      ],
      cart: {
        items: []
      }
    }
  },
  methods: {
    onAddToCart({ product }) {
      const findProduct = this.products.find(item => item.id === product.id);
      if (findProduct) {
        findProduct.inventory -= 1;
        this.cart.items.push(product);
        this.cart.total += product.price;
      }
    }
  }
}
</script>

<style lang="scss">

</style>
