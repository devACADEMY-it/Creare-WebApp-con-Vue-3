<template>
  <div class="container is-fluid">
    <section class="section">
      <h1 class="title is-2">Lista invitati (max {{ total }} posti)</h1>
      <div class="buttons">
        <button class="button is-info" @click="increaseTotal">Aumenta posti</button>
        <button class="button is-warning" @click="decreaseTotal">Diminuisci posti</button>
      </div>

      <ul>
        <li v-for="(person, idx) in people" :key="idx">
          {{ person }}
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  name: 'App',
  setup() {
    const MAX = 15;
    const total = ref(10);
    const people = ref(['Adriano', 'Gabriele', 'Piero']);

    function increaseTotal() {
      if (total.value < MAX) {
        total.value++;
      }
    }
    function decreaseTotal() {
      if (total.value > people.value.length) {
        total.value--;
      }
    }

    return { total, people, increaseTotal, decreaseTotal };
  }
}
</script>

<style lang="scss">

</style>
