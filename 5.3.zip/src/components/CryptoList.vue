<template>
  <el-table
    :data="coins"
    style="width: 100%"
  >
    <el-table-column
      prop="name"
      label="Name"
    ></el-table-column>
    <el-table-column
      label=""
    >
      <template #default="scope">
        <img :src="scope.row.image" :alt="scope.row.name">
      </template>
    </el-table-column>
    <el-table-column
      prop="current_price"
      label="Current Price"
    ></el-table-column>
  </el-table>
</template>

<script>
export default {
  data() {
    return {
      coins: [
        {
          id: "bitcoin",
          symbol: "btc",
          name: "Bitcoin",
          image:
            "https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1547033579",
          current_price: 28994,
          market_cap: 543154750885,
          market_cap_rank: 1,
          fully_diluted_valuation: 608533341843,
          total_volume: 26567781491,
          high_24h: 29208,
          low_24h: 27187,
          price_change_24h: 1153.49,
          price_change_percentage_24h: 4.14324,
          market_cap_change_24h: 21587921397,
          market_cap_change_percentage_24h: 4.13905,
          circulating_supply: 18743837,
          total_supply: 21000000,
          max_supply: 21000000,
          ath: 54205,
          ath_change_percentage: -46.54034,
          ath_date: "2021-04-14T11:54:46.763Z",
          atl: 51.3,
          atl_change_percentage: 56388.65887,
          atl_date: "2013-07-05T00:00:00.000Z",
          roi: null,
          last_updated: "2021-06-28T07:03:15.994Z",
        },
        {
          id: "ethereum",
          symbol: "eth",
          name: "Ethereum",
          image:
            "https://assets.coingecko.com/coins/images/279/large/ethereum.png?1595348880",
          current_price: 1665.39,
          market_cap: 193826186884,
          market_cap_rank: 2,
          fully_diluted_valuation: null,
          total_volume: 19913252708,
          high_24h: 1670.93,
          low_24h: 1514.85,
          price_change_24h: 98.69,
          price_change_percentage_24h: 6.29949,
          market_cap_change_24h: 11415193429,
          market_cap_change_percentage_24h: 6.25795,
          circulating_supply: 116471886.8115,
          total_supply: null,
          max_supply: null,
          ath: 3607.46,
          ath_change_percentage: -53.88268,
          ath_date: "2021-05-12T14:41:48.623Z",
          atl: 0.381455,
          atl_change_percentage: 436035.28727,
          atl_date: "2015-10-20T00:00:00.000Z",
          roi: {
            times: 75.71459173585625,
            currency: "btc",
            percentage: 7571.459173585625,
          },
          last_updated: "2021-06-28T07:03:14.641Z",
        },
        {
          id: "tether",
          symbol: "usdt",
          name: "Tether",
          image:
            "https://assets.coingecko.com/coins/images/325/large/Tether-logo.png?1598003707",
          current_price: 0.839473,
          market_cap: 52648504365,
          market_cap_rank: 3,
          fully_diluted_valuation: null,
          total_volume: 47591965529,
          high_24h: 0.844763,
          low_24h: 0.834879,
          price_change_24h: -0.003715883131,
          price_change_percentage_24h: -0.44069,
          market_cap_change_24h: -233103349.80976868,
          market_cap_change_percentage_24h: -0.4408,
          circulating_supply: 62716143411.7693,
          total_supply: 62716143411.7693,
          max_supply: null,
          ath: 1.13,
          ath_change_percentage: -25.59956,
          ath_date: "2018-07-24T00:00:00.000Z",
          atl: 0.533096,
          atl_change_percentage: 57.9295,
          atl_date: "2015-03-02T00:00:00.000Z",
          roi: null,
          last_updated: "2021-06-28T07:00:36.323Z",
        },
        {
          id: "binancecoin",
          symbol: "bnb",
          name: "Binance Coin",
          image:
            "https://assets.coingecko.com/coins/images/825/large/binance-coin-logo.png?1547034615",
          current_price: 241.55,
          market_cap: 37319223191,
          market_cap_rank: 4,
          fully_diluted_valuation: 41183155504,
          total_volume: 1135763336,
          high_24h: 243.97,
          low_24h: 226.12,
          price_change_24h: 6.06,
          price_change_percentage_24h: 2.5736,
          market_cap_change_24h: 1021856752,
          market_cap_change_percentage_24h: 2.81524,
          circulating_supply: 154533651.9,
          total_supply: 170533651.9,
          max_supply: 170533651.9,
          ath: 564.82,
          ath_change_percentage: -57.25429,
          ath_date: "2021-05-10T07:24:17.097Z",
          atl: 0.03359941,
          atl_change_percentage: 718474.03682,
          atl_date: "2017-10-19T00:00:00.000Z",
          roi: null,
          last_updated: "2021-06-28T07:02:23.959Z",
        },
      ],
    };
  },
};
</script>
