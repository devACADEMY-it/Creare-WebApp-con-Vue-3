<template>
  <el-menu
    :default-active="activeIndex"
    class="el-menu-demo"
    mode="horizontal"
    background-color="#545c64"
    text-color="#fff"
    active-text-color="#ffd04b"
  >
    <el-menu-item index="1">Homepage</el-menu-item>
    <el-menu-item index="2">About</el-menu-item>
  </el-menu>
  <CryptoList />
</template>

<script>
import CryptoList from "./components/CryptoList";

export default {
  name: "App",
  components: { CryptoList },
  data() {
    return {
      activeIndex: "1",
    };
  },
};
</script>

<style lang="scss">
#app {
  font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB",
    "Microsoft YaHei", Arial, sans-serif;
}
</style>
