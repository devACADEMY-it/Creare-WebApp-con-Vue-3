<template>
  <div class="container is-fluid">
    <nav class="navbar is-primary" role="navigation" aria-label="main navigation">
      <div class="navbar-brand">
        <a class="navbar-item" href="#">
          {{ brand }}
        </a>

        <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
        </a>
      </div>

      <div id="navbarBasicExample" class="navbar-menu">
        <div class="navbar-start">
          <a class="navbar-item">
            Home
          </a>

          <a class="navbar-item">
            Products
          </a>
        </div>
      </div>
    </nav>

    <section class="section">
      <div class="columns">
        <div class="column is-3">
          <div class="card">
            <div class="card-image">
              <figure class="image is-4by3">
                <img :src="product.imgSrc" :alt="product.name">
              </figure>
            </div>
            <div class="card-content">
              <div class="media">
                <div class="media-content">
                  <p class="title is-4">
                    {{ product.name }}
                    <span v-if="product.inventory > 10" class="tag is-medium is-light">Disponibile</span>
                    <span v-else-if="product.inventory > 0 && product.inventory <= 10" class="tag is-medium is-warning">Quasi esaurito</span>
                    <span v-else class="tag is-medium is-danger">Non disponibile</span>
                  </p>
                  <p class="subtitle is-6">{{ product.price }} €</p>
                </div>
              </div>

              <div class="content">
                {{ product.description }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      brand: 'Vue Store',
      product: {
        imgSrc: require('./assets/glasses.png'),
        name: 'Carmhack Glasses',
        inStock: false,
        price: 40,
        inventory: 0,
        description: 'Best glasses in the world',
      }
    }
  }
}
</script>

<style lang="scss">

</style>
