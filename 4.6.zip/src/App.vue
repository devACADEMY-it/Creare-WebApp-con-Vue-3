<template>
  <div class="container">
    <h1 class="title is-2">Crea evento</h1>

    <form>
      <BaseSelect label="Seleziona categoria" v-model="event.category" :options="categories" />

      <h3 class="subtitle is-3">Nome e descrizione evento</h3>
      <BaseInput label="Nome" type="text" v-model="event.name" />

      <BaseInput label="Descrizione" type="text" v-model="event.description" />

      <h3 class="subtitle is-3">Dove si svolgerà l'evento?</h3>
      <BaseInput label="Luogo evento" type="text" v-model="event.location" />

      <h3 class="subtitle is-3">Animali ammessi?</h3>
      <BaseRadioGroup
        v-model="event.animals"
        name="animals"
        :options="animalOptions"
      />

      <h3 class="subtitle is-3">Extra</h3>
      <BaseCheckbox label="Musica live" v-model="event.extra.music" />

      <BaseCheckbox label="Spettacolo" v-model="event.extra.show" />

      <button class="button is-info" type="submit">Crea</button>

      {{event}}
    </form>
  </div>
</template>

<script>
import BaseInput from "./components/BaseInput";
import BaseSelect from "./components/BaseSelect";
import BaseCheckbox from "./components/BaseCheckbox";
import BaseRadioGroup from "./components/BaseRadioGroup";

export default {
  name: 'App',
  components: {BaseCheckbox, BaseSelect, BaseInput, BaseRadioGroup},
  data() {
    return {
      animalOptions: [
        { label: 'Si', value: 1 },
        { label: 'No', value: 0 },
      ],
      categories: [
        'Natura',
        'Educazione',
        'Comunità',
        'Cibo',
        'Musica',
        'Cultura',
        'Ambiente'
      ],
      event: {
        name: '',
        description: '',
        category: 'Educazione',
        location: '',
        animals: 1,
        extra: {
          music: false,
          show: false
        }
      }
    }
  }
}
</script>

<style lang="scss">

</style>
