<template>
  <div class="columns">
    <div v-for="product in products" :key="product.id" class="column is-3">
      <Product :product="product" @addToCart="onAddToCart" />
    </div>
  </div>
</template>

<script>
import Product from "./Product";

export default {
  name: 'ProductList',
  components: {Product},
  props: {
    products: {
      type: Array,
      required: true
    }
  },
  methods: {
    onAddToCart() {
      this.$emit('addToCart');
    }
  }
}
</script>
