<template>
  <div class="container is-fluid">
    <section class="section">
      <h1 class="title is-2">Lista invitati (max {{ total }} posti)</h1>
      <h2 class="subtitle is-4">Posti rimanenti: {{ remainingGuests }}</h2>
      <div class="buttons">
        <button class="button is-info" @click="increaseTotal" :disabled="total === MAX">Aumenta posti</button>
        <button class="button is-warning" @click="decreaseTotal" :disabled="total === minimunGuests">Diminuisci posti</button>
      </div>

      <ul>
        <li v-for="(person, idx) in people" :key="idx">
          {{ person }}
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
import useEvent from './use/event';

export default {
  name: 'App',
  setup() {
    return useEvent();
  }
}
</script>

<style lang="scss">

</style>
