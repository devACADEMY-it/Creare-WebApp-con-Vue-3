import { ref, computed } from 'vue';

export default function useEvent() {
  const MAX = 15;
  const total = ref(10);
  const people = ref(['Adriano', 'Gabriele', 'Piero']);

  const remainingGuests = computed(() => {
    return total.value - people.value.length;
  });

  const minimunGuests = computed(() => {
    return people.value.length;
  });

  function increaseTotal() {
    if (total.value < MAX) {
      total.value++;
    }
  }
  function decreaseTotal() {
    if (total.value > people.value.length) {
      total.value--;
    }
  }

  return { MAX, minimunGuests, total, people, remainingGuests, increaseTotal, decreaseTotal };
}
