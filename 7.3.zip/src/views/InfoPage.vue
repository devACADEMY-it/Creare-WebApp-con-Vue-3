<template>
  <h1>Info Page</h1>
  <CryptoInfo />
</template>

<script>
import CryptoInfo from "../components/CryptoInfo";
export default {
  components: { CryptoInfo },
};
</script>
