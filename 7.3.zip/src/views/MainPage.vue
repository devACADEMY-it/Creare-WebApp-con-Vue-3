<template>
  <h1>Crypto List</h1>
  <CryptoList />
</template>

<script>
import CryptoList from "../components/CryptoList";
export default {
  components: { CryptoList },
};
</script>
