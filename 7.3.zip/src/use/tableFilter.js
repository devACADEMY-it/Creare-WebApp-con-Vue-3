import { ref } from "vue";

export default function tableFilter() {
  const search = ref("");

  function formatNumber(number) {
    return new Intl.NumberFormat("it-IT", {
      style: "currency",
      currency: "eur",
      maximumSignificantDigits: 20,
    }).format(number);
  }

  function handleNameFilter(value, row) {
    return row.name === value;
  }

  return { search, formatNumber, handleNameFilter };
}
