<template>
  <h1>Cripto Info</h1>
  <p>{{ $route.params.id }}</p>
</template>

<script>
export default {

}
</script>
