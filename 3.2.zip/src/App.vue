<template>
  <div class="container is-fluid">
    <section class="section">
      <h1 class="title is-2">Lista invitati (max {{ total }} posti)</h1>

      <ul>
        <li v-for="(person, idx) in people" :key="idx">
          {{ person }}
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  name: 'App',
  setup() {
    const total = ref(10);
    const people = ref(['Adriano', 'Gabriele', 'Piero']);

    return { total, people };
  }
}
</script>

<style lang="scss">

</style>
