<template>
  <CryptoInfo />
</template>

<script>
import CryptoInfo from "../components/CryptoInfo";
export default {
  components: { CryptoInfo },
};
</script>
