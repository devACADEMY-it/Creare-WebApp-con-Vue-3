<template>
  <div class="container is-fluid">
    <section class="section">
      <h1 class="title is-2">Lista invitati (max {{ total }} posti)</h1>
      <h2 class="subtitle is-4">Posti rimanenti: {{ remainingGuests }}</h2>
      <div class="buttons">
        <button class="button is-info" @click="increaseTotal" :disabled="total === MAX">Aumenta posti</button>
        <button class="button is-warning" @click="decreaseTotal" :disabled="total === minimunGuests">Diminuisci posti</button>
      </div>

      <ul>
        <li v-for="(person, idx) in people" :key="idx">
          {{ person }}
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
import { ref, computed } from 'vue';

export default {
  name: 'App',
  setup() {
    const MAX = 15;
    const total = ref(10);
    const people = ref(['Adriano', 'Gabriele', 'Piero']);

    const remainingGuests = computed(() => {
      return total.value - people.value.length;
    });

    const minimunGuests = computed(() => {
      return people.value.length;
    });

    function increaseTotal() {
      if (total.value < MAX) {
        total.value++;
      }
    }
    function decreaseTotal() {
      if (total.value > people.value.length) {
        total.value--;
      }
    }

    return { MAX, minimunGuests, total, people, remainingGuests, increaseTotal, decreaseTotal };
  }
}
</script>

<style lang="scss">

</style>
