<template>
  <div class="card">
    <div class="card-image">
      <figure class="image is-4by3">
        <img :src="product.imgSrc" :alt="product.name">
      </figure>
    </div>
    <div class="card-content">
      <div class="media">
        <div class="media-content">
          <p class="title is-4">
            {{ product.name }}
            <span v-if="product.inventory > 10" class="tag is-medium is-light">Disponibile</span>
            <span v-else-if="product.inventory > 0 && product.inventory <= 10" class="tag is-medium is-warning">Quasi esaurito</span>
            <span v-else class="tag is-medium is-danger">Non disponibile</span>
          </p>
          <p class="subtitle is-6">{{ product.price }} €</p>
        </div>
      </div>

      <div class="content">
        {{ product.description }}
      </div>

      <button class="button is-info" @click="addToCart">Aggiungi al carrello</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Product',
  props: {
    product: {
      type: Object,
      required: true,
    }
  },
  methods: {
    addToCart() {
      this.$emit('addToCart', { product: this.product })
    }
  }
}
</script>
