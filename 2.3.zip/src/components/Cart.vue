<template>
  <h2 class="title is-2">Totale carrello: {{ total }}</h2>
</template>

<script>
export default {
  name: 'Cart',
  props: ['total']
}
</script>
