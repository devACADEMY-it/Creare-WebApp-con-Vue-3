<template>
  <div class="container">
    <h1 class="title is-2">Crea evento</h1>

    <form @submit.prevent="onSubmit">
      <BaseSelect label="Seleziona categoria" v-model="event.category" :options="categories" />

      <fieldset>
        <legend class="subtitle is-3">Nome e descrizione evento</legend>

        <BaseInput label="Nome" type="text" v-model="event.name" error="Non puoi inserire una stringa vuota" />

        <BaseInput label="Descrizione" type="text" v-model="event.description" />
      </fieldset>

      <fieldset>
        <legend class="subtitle is-3">Dove si svolgerà l'evento?</legend>
        <BaseInput label="Luogo evento" type="text" v-model="event.location" />
      </fieldset>

      <fieldset>
        <legend class="subtitle is-3">Animali ammessi?</legend>
        <BaseRadioGroup
          v-model="event.animals"
          name="animals"
          :options="animalOptions"
        />
      </fieldset>

      <fieldset>
        <legend class="subtitle is-3">Extra</legend>
        <BaseCheckbox label="Musica live" v-model="event.extra.music" />

        <BaseCheckbox label="Spettacolo" v-model="event.extra.show" />
      </fieldset>

      <button class="button is-info" type="submit">Crea</button>
    </form>
  </div>
</template>

<script>
import BaseInput from "./components/BaseInput";
import BaseSelect from "./components/BaseSelect";
import BaseCheckbox from "./components/BaseCheckbox";
import BaseRadioGroup from "./components/BaseRadioGroup";

export default {
  name: 'App',
  components: {BaseCheckbox, BaseSelect, BaseInput, BaseRadioGroup},
  data() {
    return {
      animalOptions: [
        { label: 'Si', value: 1 },
        { label: 'No', value: 0 },
      ],
      categories: [
        'Natura',
        'Educazione',
        'Comunità',
        'Cibo',
        'Musica',
        'Cultura',
        'Ambiente'
      ],
      event: {
        name: '',
        description: '',
        category: 'Educazione',
        location: '',
        animals: 1,
        extra: {
          music: false,
          show: false
        }
      }
    }
  },
  methods: {
    onSubmit() {
      console.log('ciao');
    }
  }
}
</script>

<style lang="scss">

</style>
