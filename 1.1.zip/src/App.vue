<template>
  <div>
    <h1>Ciao!</h1>
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style lang="scss">

</style>
